/*
 * Copyright (c) 2023 Juan Manuel Cruz <jcruz@fi.uba.ar> <jcruz@frba.utn.edu.ar>.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @file   : task_pwm.c
 * @date   : Set 26, 2023
 * @author : Juan Manuel Cruz <jcruz@fi.uba.ar> <jcruz@frba.utn.edu.ar>
 * @version	v1.0.0
 */

/********************** inclusions *******************************************/
/* Project includes. */
#include "main.h"

/* Demo includes. */
#include "logger.h"
#include "dwt.h"

/* Application & Tasks includes. */
#include "board.h"
#include "app.h"

/********************** macros and definitions *******************************/

#define ADC_FULL_SCALE	(4096ul)	/* ADC de 12 bits: 0 ... 4095            */

/* 0: brillo lineal con el potenciómetro
 * 1: corrección "gamma" cuadrática (el ojo percibe el brillo de forma no
 *    lineal; así la perilla se siente más pareja en la zona baja)         */
#define PWM_USE_GAMMA	(0)

/********************** internal data declaration ****************************/

/********************** internal functions declaration ***********************/
static uint16_t adc_to_pulse(uint16_t adc_value);

/********************** internal data definition *****************************/
const char *p_task_pwm 		= "Task PWM";

/********************** external data declaration *****************************/
extern TIM_HandleTypeDef htim3;


/********************** external functions definition ************************/
void task_pwm_init(void *parameters)
{
	shared_data_type *shared_data = (shared_data_type *) parameters;

	/* Print out: Task Initialized */
	LOGGER_LOG("  %s is running - %s\r\n", GET_NAME(task_pwm_init), p_task_pwm);

	/* Arranca con el LED apagado; el PWM queda corriendo siempre
	 * y sólo se actualiza el registro de comparación (CCR1) */
	shared_data->pwm_active = 0;
	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 0);
	if (HAL_OK != HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1)) {
		LOGGER_LOG("  PWM start error\r\n");
	}
}

void task_pwm_update(void *parameters)
{
	shared_data_type *shared_data = (shared_data_type *) parameters;

	/* Event-triggered: sólo actúa cuando task_adc dejó una lectura nueva */
	if ( shared_data->adc_end_of_conversion ) {
		shared_data->adc_end_of_conversion = false;

		shared_data->pwm_active = adc_to_pulse(shared_data->adc_value);

		/* CCR1 tiene preload habilitado (OC1PE, lo pone HAL_TIM_PWM_ConfigChannel):
		 * el nuevo valor se aplica en el próximo update, sin cortar el período */
		__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, shared_data->pwm_active);
	}
}

/********************** internal functions definition ***********************/

/* Escala la lectura del ADC (0..4095) al rango del timer (0..ARR+1):
 * duty = CCR / (ARR+1) = adc / 4096                                        */
static uint16_t adc_to_pulse(uint16_t adc_value)
{
	uint32_t period = __HAL_TIM_GET_AUTORELOAD(&htim3) + 1ul;	/* ARR+1 */
	uint32_t level  = adc_value;

#if (1 == PWM_USE_GAMMA)
	level = (level * level) / (ADC_FULL_SCALE - 1ul);		/* 0..4095 */
#endif

	return (uint16_t)((level * period) / ADC_FULL_SCALE);
}

/********************** end of file ******************************************/
